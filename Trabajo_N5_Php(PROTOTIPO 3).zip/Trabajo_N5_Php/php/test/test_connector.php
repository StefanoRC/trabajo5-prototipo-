<?php ini_set("display_errors","1");?>
<?php
include_once '../connectors/connector.php';

//http://localhost/objetos/Trabajo_N5_Php/php/test/test_connector.php
    

echo '-- Inicio de Test Connector --<br>';
$connector=new Connector();
$sql="select version()";        //mariaDB
//$sql="select sqlite_version()";        //sqlite
try{
    $registros = $connector->getConnection()->query($sql);
    echo 'Conexión exitosa!<br>';
    foreach($registros as $row){
        echo 'Se conecto a '.$row[0].'<br>';
    }
}catch(Exception $e){
    echo 'Error de conexión2!<br>';
    echo $e.'<br>';
}
echo '-- Fin de Test Connector --<br>';


//INSERTAR NUEVOS VALORES A UNA TABLA

//   $connector->insert(
//     "peliculas",
//     "titulo,genero,duracion",
//     "'Bad Boys','Accion','1:20:00'"
//     );


//BORRAR O ACTUALIZAR  VALORES EN UNA TABLA

//$connector->delete("peliculas","id_pelicula=19");
//$connector->update("clientes","apellido='Pérez'","id_cliente=10");




//MOSTRAR PELICULAS DONDE EL GENERO TERMINE EN N

// echo '<br>-- Inicio Test .get() --<br>';
//  $registros = $connector->get("peliculas",
//                              "genero like '%n'");
//  foreach($registros as $row){
//      echo $row['id_pelicula'].", ".$row['titulo'].", ".$row['genero'].", ".
//           $row['duracion']."<br>";
//  }





//MOSTRAR TODOS LOS CLIENTES
// echo '<br>-- Inicio Test .getAll() --<br>';

//  $registros = $connector->getAll("clientes");
//  foreach($registros as $row){
//      echo $row['id_cliente'].", ".$row['nombre'].", ".$row['apellido'].", ".
//          $row['telefono']."<br>";
//          }




?>