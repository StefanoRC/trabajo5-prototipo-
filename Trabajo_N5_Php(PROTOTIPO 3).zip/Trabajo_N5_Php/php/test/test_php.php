<?php

phpversion();

?>
