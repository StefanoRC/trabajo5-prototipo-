-- Active: 127.0.0.1@3306@cine



drop database if exists cine;
create database cine;
use cine; 


create table peliculas (
    id_pelicula int auto_increment,
    titulo      varchar (100) not null,    
    genero      varchar (50)  not null,
    duracion    time          not null,
    primary key (id_pelicula)
);


create table clientes (
    id_cliente int auto_increment,
    nombre     varchar(100) not null,
    apellido   varchar(100) not null,
    telefono   int(15)      not null,
    primary key (id_cliente)
);

create table horarios (
    id_horario  int auto_increment,
    id_pelicula int  not null,
    fecha       date not null,
    hora        time not null,
    sala        int  not null,
    primary key (id_horario),
    foreign key (id_pelicula) references peliculas(id_pelicula)
);

create table boletos (
    id_boleto    int auto_increment,
    id_horario   int  not null,
    id_cliente   int  not null,
    cantidad     int  not null,
    precio_total int not null,
    primary key (id_boleto),
    foreign key (id_horario) references horarios(id_horario),
    foreign key (id_cliente) references clientes(id_cliente)
);
