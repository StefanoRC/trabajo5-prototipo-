--1. Seleccionar todos los clientes
select version();

--2. Seleccionar todos los clientes
select * from clientes;

--3. Seleccionar todas las peliculas
select * from peliculas;

--4. Seleccionar todos los horarios
select * from horarios;

--5. Seleccionar todos los boletos
select * from boletos;

--6. Seleccionar peliculas de accion
SELECT * FROM peliculas WHERE genero = "accion";

--7. Seleccionar clientes con inicial A
SELECT * FROM clientes WHERE nombre like 'a%';

--8. Contar la cantidad de boletos por cliente
SELECT id_boleto, COUNT(*) AS cantidad_boletos_de_clientes
FROM boletos
GROUP BY id_cliente;

--9. Obtener información de una pelicula especifica
SELECT * FROM peliculas WHERE id_pelicula = 7;

--10. Obtener horarios de la tarde 
SELECT * FROM horarios WHERE hora >'13:00:00';


