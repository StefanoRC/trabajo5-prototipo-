-- Active: 127.0.0.1@3306@cine

insert into clientes (nombre, apellido, telefono) values
('Juan', 'Pérez', 123456789),
('María', 'González', 987654321),
('Carlos', 'Rodríguez', 234567890),
('Ana', 'Martínez', 345678901),
('Luis', 'García', 456789012),
('Laura', 'Fernández', 567890123),
('Jorge', 'López', 678901234),
('Sofía', 'Díaz', 789012345),
('Miguel', 'Hernández', 890123456),
('Lucía', 'Ramírez', 901234567);


insert into peliculas (titulo, genero, duracion) values
('The Godfather', 'Crimen', '02:55:00'),
('Pulp Fiction', 'Drama', '02:34:00'),
('The Dark Knight', 'Acción', '02:32:00'),
('Forrest Gump', 'Comedia/Drama', '02:22:00'),
('Inception', 'Ciencia Ficción', '02:28:00'),
('The Matrix', 'Ciencia Ficción', '02:16:00'),
('Fight Club', 'Drama', '02:19:00'),
('Interstellar', 'Ciencia Ficción', '02:49:00'),
('The Shawshank Redemption', 'Drama', '02:22:00'),
('Gladiator', 'Acción', '02:35:00');


insert into horarios (id_pelicula, fecha, hora, sala) values
(1, '2024-12-01', '14:00:00', 1),
(2, '2024-12-01', '16:00:00', 2),
(3, '2024-12-02', '18:00:00', 1),
(4, '2024-12-02', '20:00:00', 3),
(5, '2024-12-03', '15:00:00', 2),
(1, '2024-12-03', '17:00:00', 1),
(2, '2024-12-04', '19:00:00', 3),
(3, '2024-12-04', '21:00:00', 2),
(4, '2024-12-05', '14:00:00', 1),
(5, '2024-12-05', '16:00:00', 3);


insert into boletos (id_horario, id_cliente, cantidad, precio_total) values
(1, 1, 2, 200),
(2, 2, 1, 100),
(3, 3, 4, 400),
(4, 4, 3, 300),
(5, 5, 2, 200),
(6, 6, 5, 500),
(7, 7, 1, 100),
(8, 8, 3, 300),
(9, 9, 4, 400),
(10, 10, 2, 200);

insert into boletos (id_horario, id_cliente, cantidad, precio_total) values
(1,1,10,10000);

